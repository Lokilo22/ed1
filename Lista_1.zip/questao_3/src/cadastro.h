int* cadastrarNumeros(int *v, int *num);

void exibirNumeros(int *v, int *num);

void qtdNumerosCadastrados(int *num);

void deletar(int *v);