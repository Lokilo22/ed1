void exibirVetor(int *v);

void exibirImpares(int *v);

void exibirPares(int *v);